class Menu {
  String name, image;
  double rating;
  double price;
  String id;
  Menu({this.name, this.image, this.rating, this.price, this.id});
}
